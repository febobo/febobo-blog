'use strict';
/**
 * err config
 */

exports.__esModule = true;
exports.default = {
  //key: value
  key: "errno", //error number
  msg: "errmsg" //error message
};